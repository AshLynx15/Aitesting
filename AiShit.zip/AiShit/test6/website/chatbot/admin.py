from django.contrib import admin
from .models import ChatLog

@admin.register(ChatLog)
class ChatLogAdmin(admin.ModelAdmin):
    list_display = ('user', 'message', 'intent', 'confidence', 'admin_label', 'reviewed', 'created_at')
    list_filter = ('intent', 'reviewed', 'created_at')
    search_fields = ('message', 'response', 'intent', 'admin_label')
    actions = ['mark_reviewed']

    def mark_reviewed(self, request, queryset):
        queryset.update(reviewed=True)
    mark_reviewed.short_description = "Mark selected logs as reviewed"
from django.contrib import admin
from .models import ChatbotConversationLog, ChatbotTrainingData


@admin.register(ChatbotConversationLog)
class ChatbotConversationLogAdmin(admin.ModelAdmin):
    list_display = ("user", "user_message", "bot_response", "predicted_intent", "created_at")
    list_filter = ("predicted_intent", "created_at")
    search_fields = ("user_message", "bot_response", "predicted_intent")
    readonly_fields = ("created_at",)
    ordering = ("-created_at",)


@admin.register(ChatbotTrainingData)
class ChatbotTrainingDataAdmin(admin.ModelAdmin):
    list_display = ("message", "intent", "created_at")
    list_filter = ("intent", "created_at")
    search_fields = ("message",)
    ordering = ("-created_at",)
