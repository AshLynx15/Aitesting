from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import ChatbotQuerySerializer
from .ml.model import load_model, predict_intent
from .ml.nlp_utils import simple_response
from .models import ChatbotConversationLog

class ChatbotAPIView(APIView):
    def post(self, request):
        serializer = ChatbotQuerySerializer(data=request.data)
        if serializer.is_valid():
            user_message = serializer.validated_data['message']
            try:
                # Use the model's predict_intent helper (which returns (intent, confidence))
                intent, confidence = predict_intent(user_message, threshold=0.60)
                # If model couldn't decide (low confidence), use the fallback simple_response
                if intent is None:
                    bot_reply = simple_response(user_message)
                else:
                    # Map intents to canned handlers/responses if needed
                    responses = {
                        # Example mapping - keep or extend based on your intents
                        'greeting': simple_response(user_message),
                        'order_food': 'Sure — what would you like to order?',
                        'track_order': 'Please provide your order ID and I will check the status.',
                        'recommend_food': 'Here are some recommendations for you.',
                    }
                    bot_reply = responses.get(intent, simple_response(user_message))
                # Log conversation
                ChatbotConversationLog.objects.create(
                    user=request.user if request.user.is_authenticated else None,
                    user_message=user_message,
                    bot_response=bot_reply,
                    predicted_intent=intent or 'unknown'
                )
                return Response({"response": bot_reply, "intent": intent, "confidence": confidence}, status=status.HTTP_200_OK)
            except Exception as e:
                return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
