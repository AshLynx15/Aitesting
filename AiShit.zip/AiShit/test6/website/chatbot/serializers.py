from rest_framework import serializers

class ChatbotQuerySerializer(serializers.Serializer):
    message = serializers.CharField(max_length=1000)
