from django.db import models
from django.contrib.auth.models import User

class ChatLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    message = models.TextField()
    response = models.TextField()
    intent = models.CharField(max_length=64, blank=True)
    confidence = models.FloatField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    admin_label = models.CharField(max_length=64, blank=True)
    reviewed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user} | {self.intent} | {self.message[:30]}..."
from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
from django.utils import timezone


class ChatbotTrainingData(models.Model):
    message = models.TextField()
    intent = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.intent}: {self.message[:30]}"
    
class ChatbotConversationLog(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    user_message = models.TextField()
    bot_response = models.TextField()
    predicted_intent = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        user_name = self.user.username if self.user else "Guest"
        return f"{user_name} ({self.created_at:%Y-%m-%d %H:%M})"