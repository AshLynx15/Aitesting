from sklearn.ensemble import RandomForestClassifier
import joblib, os

# Store model + vectorizer together so they stay in sync
MODEL_PATH = "chatbot/ml/chatbot_model.pkl"

def train_model(X, y, vectorizer=None):
    """
    Train a RandomForestClassifier on the given features and labels.
    Optionally save the fitted vectorizer along with the model.
    """
    model = RandomForestClassifier()
    model.fit(X, y)

    # Save both model and vectorizer (important!)
    # Use a tuple for compatibility with training scripts that expect (model, vectorizer)
    data_to_save = (model, vectorizer)
    joblib.dump(data_to_save, MODEL_PATH)

    return model

def load_model():
    """Load the saved model and vectorizer from disk.

    Returns:
        (model, vectorizer) or (None, None) if not available.
    """
    if os.path.exists(MODEL_PATH):
        data = joblib.load(MODEL_PATH)
        # data may be saved as a tuple (model, vectorizer) or a dict {"model":..., "vectorizer":...}
        if isinstance(data, dict):
            model = data.get('model')
            vectorizer = data.get('vectorizer')
        else:
            try:
                model, vectorizer = data
            except Exception:
                # unexpected format
                return None, None
        return model, vectorizer
    return None, None

def predict_intent(text, threshold=0.6):
    """Predict intent and return (intent_label_or_None, confidence_score).

    If confidence is below threshold, returns (None, confidence).
    """
    model, vectorizer = load_model()
    if model is None or vectorizer is None:
        return None, 0.0

    # Lazy import to avoid circular imports at module import time
    try:
        from .nlp_utils import normalize_text
    except Exception:
        # fallback simple normalization
        def normalize_text(x):
            return x.lower().strip()

    clean = normalize_text(text)
    X = vectorizer.transform([clean])

    # If classifier supports predict_proba, use it to compute confidence
    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(X)[0]
        best_idx = int(probs.argmax())
        best_prob = float(probs[best_idx])
        label = model.classes_[best_idx]
        if best_prob < threshold:
            return None, best_prob
        return label, best_prob
    else:
        label = model.predict(X)[0]
        return label, 1.0
