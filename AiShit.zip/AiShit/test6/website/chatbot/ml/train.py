# --- Django integration ---
import os
import sys

# Add the folder where manage.py is (project root)
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# PROJECT_ROOT = test6/website/
sys.path.append(PROJECT_ROOT)

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'website.settings')

import django
django.setup()


# --- ML imports ---
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
import joblib

from webpage.models import Product  # ✅ only what we need
from chatbot.ml.nlp_utils import normalize_text

MODEL_PATH = "chatbot/ml/chatbot_model.pkl"

training_sentences = []
training_labels = []

# Optional: include manually added chatbot training data
try:
    from chatbot.models import ChatbotTrainingData
    for row in ChatbotTrainingData.objects.all():
        if row.text and row.label:
            training_sentences.append(str(row.text))
            training_labels.append(str(row.label))
except Exception:
    pass

# ✅ Add product-related training samples (no ordering / no tracking)
for p in Product.objects.all():
    training_sentences.append(f"Do you have {p.name}?")
    training_labels.append("ask_menu")

    training_sentences.append(f"Tell me about {p.name}")
    training_labels.append("ask_menu")

    training_sentences.append(f"Recommend something like {p.name}")
    training_labels.append("recommend_similar")

# ✅ Add some general/greeting/fallback training examples
greetings = ["hi", "hello", "hey", "good day", "what's up"]
for g in greetings:
    training_sentences.append(g)
    training_labels.append("greeting")

fallbacks = ["I don't understand", "What can you do", "help", "menu"]
for f in fallbacks:
    training_sentences.append(f)
    training_labels.append("fallback")

# --- Normalize texts ---
normalized = [normalize_text(t) for t in training_sentences if t and t.strip()]
labels = [l for i, l in enumerate(training_labels) if training_sentences[i] and training_sentences[i].strip()]

# --- Train model ---
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(normalized)

param_grid = {'n_estimators': [100, 200], 'max_depth': [None, 20]}
clf = GridSearchCV(RandomForestClassifier(), param_grid=param_grid, cv=3, n_jobs=-1)
clf.fit(X, labels)
model = clf.best_estimator_

# --- Save model ---
joblib.dump((model, vectorizer), MODEL_PATH)
print("✅ Chatbot model (recommendation-only) trained and saved at", MODEL_PATH)
