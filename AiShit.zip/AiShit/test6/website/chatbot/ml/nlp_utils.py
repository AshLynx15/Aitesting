import random
import re
import difflib
import django, os
from django.db.models import Sum

# Initialize Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'website.settings')
django.setup()

from webpage.models import Product, OrderItem
from webpage.utils import get_customization_options  # keep only this import

# ---------------- NLP setup ---------------- #
try:
    import spacy
    try:
        nlp = spacy.load("en_core_web_sm")
    except Exception:
        nlp = spacy.blank("en")
except Exception:
    spacy = None
    nlp = None


# ---------------- Text normalization ---------------- #
def normalize_text(text):
    """Clean and normalize text before NLP processing."""
    text = (text or "").strip().lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()

    if nlp is not None:
        try:
            doc = nlp(text)
            tokens = [
                (token.lemma_.lower() if token.lemma_ else token.text.lower())
                for token in doc
                if not token.is_stop and not token.is_space
            ]
            if tokens:
                return " ".join(tokens)
        except Exception:
            pass

    return text


# ---------------- Entity extraction ---------------- #
def extract_entities(text):
    """Extract product mentions and customizations from text (with partial/fuzzy match)."""
    text = normalize_text(text)
    entities = {'products': [], 'customizations': []}

    # Get all product names
    all_products = list(Product.objects.values_list('name', flat=True))
    normalized_products = {normalize_text(p): p for p in all_products}

    for norm_name, original_name in normalized_products.items():
        # ✅ Exact match
        if norm_name in text:
            entities['products'].append(original_name)
            continue

        # ✅ Substring or phrase match
        if text in norm_name or difflib.SequenceMatcher(None, text, norm_name).ratio() > 0.7:
            entities['products'].append(original_name)
            continue

        # ✅ Word-level fuzzy match
        for word in text.split():
            if difflib.SequenceMatcher(None, word, norm_name).ratio() > 0.7:
                entities['products'].append(original_name)
                break

    # ✅ Detect simple customizations like “no sugar” or “extra pearl”
    if 'no' in text or 'extra' in text:
        parts = text.split()
        for i, w in enumerate(parts):
            if w in ('no', 'extra') and i + 1 < len(parts):
                entities['customizations'].append(f"{w} {parts[i + 1]}")

    entities['products'] = list(set(entities['products']))
    entities['customizations'] = list(set(entities['customizations']))

    return entities


# ---------------- Top-selling recommender ---------------- #
def get_top_products(limit=3):
    """Return top N most ordered products based on quantity."""
    top_products = (
        OrderItem.objects
        .values('product__name')
        .annotate(total_orders=Sum('quantity'))
        .order_by('-total_orders')[:limit]
    )
    return [p['product__name'] for p in top_products]


# ---------------- Hugging Face Fallback ---------------- #
try:
    from transformers import pipeline
    hf_generator = pipeline('text-generation', model='gpt2', device=-1)
except Exception:
    hf_generator = None

# ---------------- Intent Classification (Random Forest) ---------------- #
def classify_intent(text, clf=None, vectorizer=None):
    """Classify intent using Random Forest model and vectorizer."""
    if clf and vectorizer:
        processed = normalize_text(text)
        X_vec = vectorizer.transform([processed])
        intent_pred = clf.predict(X_vec)[0]
        intent_proba = max(clf.predict_proba(X_vec)[0])
        return intent_pred, intent_proba
    return None, 0

# ---------------- Chatbot Response ---------------- #
def simple_response(user_input, session=None, user=None, clf=None, vectorizer=None):
    """Chatbot for conversation and recommendations only (no ordering actions)."""
    user_input = (user_input or "").lower()
    entities = extract_entities(user_input)

    if session is None:
        session = {}

    # 🟢 Greetings (20 variations)
    greetings = [
        "Hello! Welcome to our shop 👋 What can I get for you today?",
        "Hi there! 😊 Craving something sweet or refreshing?",
        "Greetings! Ready to order something delicious?",
        "Hey! I'm FoodBot 🤖 What are you in the mood for?",
        "Good day! ☀️ Looking for your favorite drink or something new?",
        "Welcome back! Wanna try one of our top picks today?",
        "Hi 👋 What can I serve you?",
        "Hey hey! 😄 Hungry or thirsty? I’ve got options.",
        "Hello there! Want to see our bestsellers?",
        "Hi! 👋 Ready to explore our menu?",
        "Welcome to the flavor zone 🎉 What do you feel like having?",
        "Hey friend! 😊 Let's find something delicious for you.",
        "Hiya! 🍰 Craving dessert or drinks today?",
        "Hello 👋 It’s a great time for a treat, isn’t it?",
        "Yo! 😎 Ready to try something new?",
        "Hi there 🙌 What would you like to order?",
        "Hello! How’s your day going? Want to see our menu?",
        "Hi! ✨ Need a recommendation?",
        "Hey! 🍹 Let’s find you the perfect drink.",
        "Greetings 👋 Let me help you pick something tasty."
    ]

    # 🟡 Cache top products once per request
    top_products = get_top_products()
    if top_products:
        top_names = ", ".join(top_products)
        recommendations = [
            f"Our bestsellers are {top_names}. Would you like to know more about them?",
            f"Customers really love {top_names}! Want me to tell you more?",
            f"These are flying off the shelves 🛒: {top_names}. Want details?",
            f"If you’re not sure what to pick, {top_names} are excellent choices.",
            f"✨ Top picks right now: {top_names}. Want to hear more?",
            f"People can’t get enough of {top_names}! Should I tell you more?",
            f"Our crowd favorites: {top_names}. Interested?",
            f"{top_names} are among the most ordered items. Curious?",
            f"🔥 Top recommendations: {top_names}. Want more info?",
            f"If you're craving something special, try {top_names}.",
            f"Looking for the best? {top_names} are the winners 🏆",
            f"Top-selling treats 🍰: {top_names}. Want to check them out?",
            f"Our customers keep coming back for {top_names}.",
            f"Not sure what to get? {top_names} are a safe bet!",
            f"Here’s what everyone’s loving lately: {top_names}",
            f"These are trending right now 👑: {top_names}",
            f"Our chef recommends 🍳: {top_names}.",
            f"Craving something tried and true? Go for {top_names}.",
            f"Here’s a quick list of our best picks: {top_names}",
            f"Feeling adventurous? Start with our bestsellers: {top_names}"
        ]
    else:
        recommendations = [
            "We have many great items — would you like to see our popular choices?"
        ]

    # ---- Greetings ----
    if any(greet in user_input for greet in ("hello", "hi", "hey", "good day", "greetings")):
        return random.choice(greetings)

    # ---- Menu ----
    if 'menu' in user_input:
        return "Here's our menu! Which item catches your eye?"

    # ---- Tracking ----
    if any(word in user_input for word in ('track', 'delivery', 'where')):
        return "You can check your order status on the order tracking page."

    # ✅ Best seller / Recommendation queries
    if any(phrase in user_input for phrase in [
        "best seller", "bestseller", "recommend", "what's good",
        "what would you recommend", "top picks", "popular", "what is the best"
    ]):
        if top_products:
            session['bestseller_list'] = top_products
            return random.choice(recommendations)
        else:
            return "We have plenty of delicious items, but I don't have bestseller data right now."

    # ---- Product mentioned ----
    if entities.get('products'):
        session['interested_product'] = entities['products'][0]
        return f"{entities['products'][0]} is one of our favorites! Would you like to hear more about it?"

    # ---- Yes Handling ----
    if "yes" in user_input:

        # ✅ User said yes after bestsellers recommendation
        if session.get('bestseller_list'):
            bestseller_product = session['bestseller_list'][0]
            session.pop('bestseller_list', None)
            session['interested_product'] = bestseller_product
            return f"Great choice! {bestseller_product} is one of our top picks. Would you like to hear more about it?"

        # ✅ User said yes to product info
        if session.get('interested_product'):
            product_name = session.pop('interested_product')

            try:
                product = Product.objects.get(name=product_name)
            except Product.DoesNotExist:
                return f"Awesome! {product_name} is made fresh daily. Would you like recommendations similar to it?"

            response_lines = [f"Awesome! {product.name} is made fresh daily."]

            # ✅ Show size options & prices if applicable
            if getattr(product, 'has_sizes', False):
                size_lines = []
                if product.price_16oz:
                    size_lines.append(f" - 16oz (₱{product.price_16oz})")
                if product.price_32oz:
                    size_lines.append(f" - 32oz (₱{product.price_32oz})")
                if size_lines:
                    response_lines.append("Available sizes:")
                    response_lines.extend(size_lines)

            # ✅ Ask if user wants customization
            session['show_customization_for'] = product.name
            response_lines.append(f"Would you like to see the customization of {product.name}?")
            return "\n".join(response_lines)

        # ✅ User said yes to customization options
        if session.get('show_customization_for'):
            product_name = session.pop('show_customization_for', None)

            try:
                product = Product.objects.get(name=product_name)
            except Product.DoesNotExist:
                return f"Sorry, I couldn't find customization details for {product_name}."

            options = get_customization_options(product.type)
            session['last_viewed_product'] = product.name

            if options:
                category_icons = {
                    'sugar': '🍬',
                    'ice': '🧊',
                    'water': '💧',
                    'whipped_cream': '🍦',
                    'tapioca': '🧋',
                    'milk': '🥛'
                }

                response_lines = [f"Here are the customization options for **{product.name}** 🛠️:"]
                for category, vals in options.items():
                    icon = category_icons.get(category.lower(), '•')
                    vals_str = " | ".join([str(v) for v in vals])
                    response_lines.append(f"{icon} **{category.capitalize()}**: {vals_str}")
                response_lines.append("\nWould you like other recommendations similar to this?")
                return "\n".join(response_lines)
            else:
                return f"{product.name} has no special customization options."

        # ✅ User said yes after customization (similar recommendations)
        if session.get('last_viewed_product'):
            last_product_name = session['last_viewed_product']
            similar = [p for p in top_products if p != last_product_name]
            if similar:
                similar_names = ", ".join(similar)
                return f"If you like {last_product_name}, you might also enjoy {similar_names}! 😋"
            else:
                return f"{last_product_name} is pretty unique — but it's a bestseller for a reason! 🏆"

        return "Sure! What kind of food or drink are you in the mood for?"

    # ---- No Handling ----
    if "no" in user_input:
        session.clear()
        return "No problem! Maybe I can recommend something else?"

    # ---- Similar / Other Recommendations ----
    if any(phrase in user_input for phrase in ["similar", "like this", "other recommendation", "recommendations like"]):
        last_product_name = session.get('last_viewed_product')
        if last_product_name:
            similar = [p for p in top_products if p != last_product_name]
            if similar:
                similar_names = ", ".join(similar)
                return f"If you like {last_product_name}, you might also enjoy {similar_names}!"
            else:
                return f"I don't have exact matches right now, but {last_product_name} is one of our bestsellers!"
        else:
            return "Could you tell me which product you'd like similar recommendations for?"
        
        # ---------------- 📝 Category & Product Listing ---------------- #
    # Get all category names from the Product model
    all_categories = list(Product.objects.values_list('type', flat=True).distinct())

    # ✅ List all products
    if "list all products" in user_input or "show all products" in user_input:
        if not all_categories:
            return "I couldn't find any categories or products in the database."
        response_lines = ["📋 **All Products by Category:**"]
        for cat in all_categories:
            items = Product.objects.filter(type=cat).values_list('name', flat=True)
            if items:
                response_lines.append(f"\n🍽 **{cat.capitalize()}**:")
                for name in items:
                    response_lines.append(f" - {name}")
        return "\n".join(response_lines)

    # ✅ List all best sellers in each category
    if "list all best seller" in user_input or "best sellers in each category" in user_input:
        if not all_categories:
            return "I couldn't find any categories or products in the database."
        response_lines = ["🏆 **Best Sellers by Category:**"]
        for cat in all_categories:
            top_in_cat = (
                OrderItem.objects
                .filter(product__type=cat)
                .values('product__name')
                .annotate(total_orders=Sum('quantity'))
                .order_by('-total_orders')[:3]
            )
            if top_in_cat:
                response_lines.append(f"\n🍽 **{cat.capitalize()}**:")
                for p in top_in_cat:
                    response_lines.append(f" - {p['product__name']} ({p['total_orders']} orders)")
        return "\n".join(response_lines)

    # ✅ List all in a specific category
    if "list all in" in user_input:
        # extract the category name part after "list all in"
        parts = user_input.split("list all in", 1)
        if len(parts) > 1:
            requested_category = parts[1].strip()

            # try exact match first
            matched_category = None
            for cat in all_categories:
                if requested_category.lower() == cat.lower():
                    matched_category = cat
                    break

            # try fuzzy match if exact didn't work
            if not matched_category:
                match = difflib.get_close_matches(requested_category.lower(), [c.lower() for c in all_categories], n=1, cutoff=0.6)
                if match:
                    # find original category name (case-sensitive)
                    for cat in all_categories:
                        if cat.lower() == match[0]:
                            matched_category = cat
                            break

            if matched_category:
                products_in_cat = Product.objects.filter(type__iexact=matched_category).values_list('name', flat=True)
                if products_in_cat:
                    response_lines = [f"📂 **Products in {matched_category.capitalize()}:**"]
                    for name in products_in_cat:
                        response_lines.append(f" - {name}")
                    return "\n".join(response_lines)
                else:
                    return f"Sorry, I couldn't find any products in the category **{matched_category}**."
            else:
                return f"Sorry, I couldn't find any category that matches **{requested_category}**."


    # ---- Fallback ----
    # Try intent classification
    intent, confidence = classify_intent(user_input, clf, vectorizer)
    if confidence >= 0.6 and intent:
        # You can add more intent-based responses here
        return f"Intent detected: {intent}. How can I help with that?"
    # Hugging Face fallback
    # ---- Fallback ----
    intent, confidence = classify_intent(user_input, clf, vectorizer)
    if confidence >= 0.6 and intent:
        return f"Intent detected: {intent}. How can I help with that?"

    # --- Hugging Face fallback (with bestseller extension) ---
    if hf_generator:
        try:
            prompt = (
                "Answer as a helpful food assistant. "
                "Keep it short and clear — one or two sentences only.\n\n"
                f"Question: {user_input}\nAnswer:"
            )

            hf_output = hf_generator(
                prompt,
                max_new_tokens=40,
                temperature=0.6,
                top_p=0.9,
                do_sample=True,
                truncation=True,
                pad_token_id=50256
            )

            hf_reply = hf_output[0]['generated_text']
            hf_reply = hf_reply.replace(prompt, "").strip()

            if "." in hf_reply:
                hf_reply = hf_reply.split(".")[0].strip() + "."

            if not hf_reply or hf_reply.lower().startswith(("question", "answer", "user", "assistant")):
                hf_reply = "I'm not sure, but I think it's related to food."

            # ✅ Add bestseller extension dynamically
            top_products = get_top_products()
            if top_products:
                top_names = ", ".join(top_products)
                hf_reply += f" By the way, our bestsellers are {top_names} — would you like to know more about them?"

            return hf_reply

        except Exception as e:
            print("Hugging Face fallback error:", e)
            return "I'm sorry, I’m having trouble understanding that right now."




    # Default fallback
    return random.choice([
        "I'm not sure I got that — are you looking for drinks, snacks, or desserts?",
        "Would you like to see our top picks?",
        "I didn’t quite get that. Maybe you'd like our milk tea collection?",
        "Can you rephrase your question? I'm here to help!",
        "Sorry, I don't have an answer for that yet. Would you like to see our menu?",
        "If you need help, just ask for recommendations or type 'menu'."
    ])
