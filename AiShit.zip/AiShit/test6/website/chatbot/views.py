import joblib
import os
import re
from .models import ChatLog
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from transformers import pipeline

# Load model and vectorizer
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'ml', 'model.pkl')
VECTORIZER_PATH = os.path.join(os.path.dirname(__file__), 'ml', 'vectorizer.pkl')
clf = joblib.load(MODEL_PATH) if os.path.exists(MODEL_PATH) else None
vectorizer = joblib.load(VECTORIZER_PATH) if os.path.exists(VECTORIZER_PATH) else None

# Load Hugging Face local model (must be downloaded)
try:
    hf_generator = pipeline('text-generation', model='gpt2', device=-1)
except Exception:
    hf_generator = None

def preprocess(text):
    text = text.lower()
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    return text

@csrf_exempt
@login_required
def chatbot_api(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required'}, status=400)
    user_message = request.POST.get('message', '')
    processed = preprocess(user_message)
    intent = ''
    confidence = 0
    response = ''
    # Predict intent
    if clf and vectorizer:
        X_vec = vectorizer.transform([processed])
        intent_pred = clf.predict(X_vec)[0]
        intent_proba = max(clf.predict_proba(X_vec)[0])
        intent = intent_pred
        confidence = float(intent_proba)
    # If confident, use predefined response
    if confidence >= 0.6:
        response = get_predefined_response(intent)
    else:
        # Fallback to Hugging Face local model
        if hf_generator:
            response = hf_generator(user_message, max_length=50)[0]['generated_text']
        else:
            response = "Sorry, I can't answer that right now."
    # Save chat log
    ChatLog.objects.create(
        user=request.user,
        message=user_message,
        response=response,
        intent=intent,
        confidence=confidence
    )
    return JsonResponse({'reply': response, 'intent': intent, 'confidence': confidence})

def get_predefined_response(intent):
    # Example: you should expand this dictionary
    responses = {
        'greeting': 'Hello! How can I help you today?',
        'order_food': 'What would you like to order?',
        'goodbye': 'Thank you! Have a great day!',
        # Add more intents and responses here
    }
    return responses.get(intent, 'I am not sure how to help with that.')
from django.shortcuts import render
from django.http import JsonResponse
from .models import ChatbotConversationLog, ChatbotTrainingData
from .ml.model import load_model
from .ml.nlp_utils import simple_response, extract_entities
from django.views.decorators.csrf import csrf_exempt


@csrf_exempt  # optional if using JS fetch without CSRF token
def chatbot_page(request):
    """Render chatbot UI page."""
    return render(request, "chat.html")


@csrf_exempt
def chatbot_response(request):
    """Handle chatbot AJAX requests."""
    user_message = request.GET.get("message", "").strip()
    session = request.session

    # 🧠 Auto-greet once per session
    if not session.get("greeted", False):
        session["greeted"] = True
        greeting = simple_response("greet", session=session)
        return JsonResponse({"response": greeting})

    # 🛑 Validate message
    if not user_message:
        return JsonResponse({"error": "No message provided."}, status=400)

    try:
        # 🤖 Load model (if trained)
        model_data = load_model()
        intent = "basic"

        if model_data:
            model, vectorizer = model_data
            X = vectorizer.transform([user_message])
            intent = model.predict(X)[0]

        # 💬 Generate chatbot reply
        bot_reply = simple_response(user_message, session=session)

        # 📝 Log conversation
        ChatbotConversationLog.objects.create(
            user=request.user if request.user.is_authenticated else None,
            user_message=user_message,
            bot_response=bot_reply,
            predicted_intent=intent,
        )

        # 📚 Save training data for retraining (only new or short messages)
        if len(user_message) <= 300:
            ChatbotTrainingData.objects.create(
                message=user_message, intent=intent
            )

        return JsonResponse({"response": bot_reply, "intent": intent})

    except Exception as e:
        return JsonResponse({"error": f"Chatbot error: {str(e)}"}, status=500)


def chat_history(request):
    """Retrieve the last 20 chatbot exchanges."""
    logs = ChatbotConversationLog.objects.order_by("-created_at")[:20][::-1]
    data = [
        {
            "user": log.user.username if log.user else "Guest",
            "user_message": log.user_message,
            "bot_response": log.bot_response,
            "intent": log.predicted_intent,
            "timestamp": log.created_at.strftime("%Y-%m-%d %H:%M"),
        }
        for log in logs
    ]
    return JsonResponse(data, safe=False)
