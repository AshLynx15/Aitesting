from django.contrib import admin
from .models import Rider, Delivery, DeliveryLocation


# === RIDER ADMIN ===
@admin.register(Rider)
class RiderAdmin(admin.ModelAdmin):
    # Show all fields automatically
    list_display = [field.name for field in Rider._meta.fields]

    # Search across related user + location
    search_fields = ('name', 'location', 'user__username', 'user__email')

    # Add filters if Rider has role/status/etc.
    list_filter = ('location',)


# === DELIVERY ADMIN ===
@admin.register(Delivery)
class DeliveryAdmin(admin.ModelAdmin):
    # Show all fields automatically
    list_display = [field.name for field in Delivery._meta.fields]

    # Search by ID, rider, status
    search_fields = ('id', 'rider__name', 'rider__user__username', 'status')

    # Filters for quick management
    list_filter = ('status',)


# === DELIVERY LOCATION ADMIN ===
@admin.register(DeliveryLocation)
class DeliveryLocationAdmin(admin.ModelAdmin):
    # Show all fields automatically
    list_display = [field.name for field in DeliveryLocation._meta.fields]

    # Filters
    list_filter = ('is_rider', 'updated_at')

    # Search across user fields
    search_fields = ('user__username', 'user__email')

    # Prevent editing system fields
    readonly_fields = ('updated_at',)
