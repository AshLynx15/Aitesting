from django.urls import path
from . import views

app_name = 'delivery'

urlpatterns = [
    path('map/', views.map_view, name='delivery_map'),
    path('rider/location/', views.rider_location_view, name='rider_location_view'),
    path('calculate_route/', views.calculate_route_view, name='calculate_route_view'),
    path('update-location/', views.update_location, name='update_location'),
    path('get_locations/<int:order_id>/', views.get_locations, name='get_locations'),

    path('orders/customer/', views.customer_orders, name='customer_orders'),
    path('orders/rider/', views.rider_orders, name='rider_orders'),
    path('orders/available/', views.available_orders, name='available_orders'),
    path('orders/<int:order_id>/claim/', views.claim_order, name='claim_order'),
    path('orders/<int:order_id>/map/', views.order_map, name='order_map'),
    path("orders/<int:pk>/rider-success/", views.rider_success, name="rider_success"),
]
