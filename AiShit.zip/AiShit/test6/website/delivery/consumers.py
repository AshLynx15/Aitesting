import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.core.exceptions import ObjectDoesNotExist
from webpage.models import Order  # canonical Order model


class LocationConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.order_id = self.scope['url_route']['kwargs']['order_id']
        self.room_group_name = f'order_{self.order_id}'
        user = self.scope.get("user", None)

        if not user or not user.is_authenticated:
            await self.close()
            return

        has_perm = await self.user_has_order_permission(user, self.order_id)
        if not has_perm:
            await self.close()
            return

        await self.channel_layer.group_add(self.room_group_name, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.room_group_name, self.channel_name)

    async def receive(self, text_data=None, bytes_data=None):
        try:
            data = json.loads(text_data)
            lat = float(data.get('lat'))
            lng = float(data.get('lng'))
            role = data.get('role', '')
        except Exception:
            return

        payload = {
            "type": "location.update",
            "lat": lat,
            "lng": lng,
            "role": role,
            "user_id": self.scope["user"].id
        }
        await self.channel_layer.group_send(self.room_group_name, {
            "type": "broadcast_location",
            "payload": payload
        })

    async def broadcast_location(self, event):
        payload = event['payload']
        # Keep only what the frontend needs
        clean = {
            "lat": payload["lat"],
            "lng": payload["lng"],
            "role": payload["role"]
        }
        await self.send(text_data=json.dumps(clean))


    @database_sync_to_async
    def user_has_order_permission(self, user, order_id):
        try:
            order = Order.objects.get(pk=order_id)
        except ObjectDoesNotExist:
            return False

        is_customer = order.user_id == user.id
        is_rider = order.rider_id == user.id if order.rider_id else False
        return bool(is_customer or is_rider)
