document.addEventListener('DOMContentLoaded', function () {
  var mapDiv = document.getElementById('map');
  if (!mapDiv) {
    console.log('[DEBUG] #map container not found, skipping map JS.');
    return;
  }

  // --- Init map ---
  var map = L.map("map").setView([14.5995, 120.9842], 13);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "&copy; OpenStreetMap contributors",
  }).addTo(map);

  let customerMarker = null;
  let riderMarker = null;
  let routeLine = null;

  // --- Page type flag (set in template, default false) ---
  const IS_ORDER_MAP = typeof window.IS_ORDER_MAP !== "undefined" ? window.IS_ORDER_MAP : false;

  // --- Custom icons ---
  const riderIcon = L.icon({
    iconUrl: "/static/delivery_app/icons/rider.png",
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32],
  });

  const customerIcon = L.icon({
    iconUrl: "/static/delivery_app/icons/customer.png",
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32],
  });

  // --- WebSocket with auto-reconnect ---
  let socket = null;
  let reconnectDelay = 1000;

  function connectSocket() {
    if (typeof WS_URL === "undefined") {
      console.warn("[map.js] WS_URL not defined, skipping WebSocket.");
      return;
    }
    socket = new WebSocket(WS_URL);

    socket.onopen = function () {
      console.log("[WS] Connected.");
      reconnectDelay = 1000;
    };

    socket.onmessage = function (event) {
      const data = JSON.parse(event.data);
      if (data.lat && data.lng && data.role) {
        if (data.role === "rider") {
          updateRiderMarker(data.lat, data.lng);
        } else {
          updateCustomerMarker(data.lat, data.lng);
        }
      }
    };

    socket.onclose = function () {
      console.warn("[WS] Disconnected. Reconnecting in " + reconnectDelay / 1000 + "s...");
      setTimeout(connectSocket, reconnectDelay);
      reconnectDelay = Math.min(reconnectDelay * 2, 30000);
    };

    socket.onerror = function (err) {
      console.error("[WS] Error:", err);
      socket.close();
    };
  }

  if (typeof WS_URL !== "undefined") {
    connectSocket();
  }

  // --- Safe send ---
  function safeSend(data) {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(data));
    } else {
      console.debug("[WS] Skipped send, socket not active:", data);
    }
  }

  // --- Form elements ---
  const latInput = document.getElementById("latitude");
  const lngInput = document.getElementById("longitude");
  const latDebug = document.getElementById("lat-debug");
  const lngDebug = document.getElementById("lng-debug");
  const submitBtn = document.getElementById("submit-btn");
  const addBtn = document.getElementById("add-location");
  const removeBtn = document.getElementById("remove-marker");

  function setLocation(lat, lng) {
    if (latInput) latInput.value = lat;
    if (lngInput) lngInput.value = lng;
    if (latDebug) latDebug.textContent = lat || "(not set)";
    if (lngDebug) lngDebug.textContent = lng || "(not set)";
  }

// --- Draw route + ETA + optional rider simulation ---
function drawRoute(simulate = false) {
  if (!riderMarker || !customerMarker) return;
  if (routeLine) {
    map.removeLayer(routeLine);
    routeLine = null;
  }
  const from = riderMarker.getLatLng();
  const to = customerMarker.getLatLng();
  const url = `https://router.project-osrm.org/route/v1/driving/${from.lng},${from.lat};${to.lng},${to.lat}?overview=full&geometries=geojson`;

  fetch(url)
    .then((r) => r.json())
    .then((data) => {
      if (data.routes.length) {
        const coords = data.routes[0].geometry.coordinates.map((c) => [c[1], c[0]]);
        routeLine = L.polyline(coords, { color: "blue", weight: 4 }).addTo(map);

        const etaEl = document.getElementById("eta-text");
        const distEl = document.getElementById("distance-text");
        if (etaEl) etaEl.innerText = `ETA: ${Math.round(data.routes[0].duration / 60)} min`;
        if (distEl) distEl.innerText = `Distance: ${(data.routes[0].distance / 1000).toFixed(2)} km`;

        // --- Simulate rider moving step by step ---
        if (simulate) {
          let i = 0;
          const interval = setInterval(() => {
            if (i >= coords.length) {
              clearInterval(interval);
              console.log("[SIM] Rider reached customer 🚴");

              if (typeof USER_ROLE !== "undefined") {
                if (USER_ROLE === "rider") {
                  window.location.href = `/delivery/orders/${ORDER_ID}/rider-success/`;
                } else {
                  window.location.href = `/orders/${ORDER_ID}/customer-feedback/`;
                }
              }
              return;
            }
            const [lat, lng] = coords[i];
            updateRiderMarker(lat, lng);
            safeSend({ lat, lng, role: "rider" });
            i++;
          }, 500);
        }
      }
    });
}


  // --- Customer marker handling ---
  function updateCustomerMarker(lat, lng) {
    if (!customerMarker) {
      customerMarker = L.marker([lat, lng], {
        icon: customerIcon,
        draggable: !IS_ORDER_MAP,   // 🚫 disable dragging in order map
        title: "Customer"
      }).addTo(map);

      if (!IS_ORDER_MAP) {
        // Remove on click
        customerMarker.on("click", function () {
          map.removeLayer(customerMarker);
          customerMarker = null;
          setLocation("", "");
          if (submitBtn) submitBtn.disabled = true;
          if (routeLine) {
            map.removeLayer(routeLine);
            routeLine = null;
          }
        });

        // Drag updates
        customerMarker.on("dragend", function (e) {
          const { lat, lng } = e.target.getLatLng();
          safeSend({ lat, lng, role: "customer" });
          setLocation(lat, lng);
          if (submitBtn) submitBtn.disabled = false;
          drawRoute();
        });
      }
    } else {
      customerMarker.setLatLng([lat, lng]);
    }

    map.setView([lat, lng], 18);
    safeSend({ lat, lng, role: "customer" });
    setLocation(lat, lng);
    if (submitBtn) submitBtn.disabled = false;
    drawRoute();
  }

  // --- Rider marker handling ---
  function updateRiderMarker(lat, lng) {
    if (!riderMarker) {
      riderMarker = L.marker([lat, lng], { icon: riderIcon, title: "Rider" }).addTo(map);
    } else {
      riderMarker.setLatLng([lat, lng]);
    }
    drawRoute();
  }

  // --- Preload saved locations from Django ---
  if (typeof INITIAL_CUSTOMER_LAT !== "undefined" && INITIAL_CUSTOMER_LAT !== null &&
      typeof INITIAL_CUSTOMER_LNG !== "undefined" && INITIAL_CUSTOMER_LNG !== null) {
    console.log("[DEBUG] Preloading customer marker:", INITIAL_CUSTOMER_LAT, INITIAL_CUSTOMER_LNG);
    updateCustomerMarker(INITIAL_CUSTOMER_LAT, INITIAL_CUSTOMER_LNG);
  }

  if (typeof INITIAL_RIDER_LAT !== "undefined" && INITIAL_RIDER_LAT !== null &&
      typeof INITIAL_RIDER_LNG !== "undefined" && INITIAL_RIDER_LNG !== null) {
    console.log("[DEBUG] Preloading rider marker:", INITIAL_RIDER_LAT, INITIAL_RIDER_LNG);
    updateRiderMarker(INITIAL_RIDER_LAT, INITIAL_RIDER_LNG);
  }

  // Auto-fit if both exist
  if (customerMarker && riderMarker) {
    const group = new L.featureGroup([customerMarker, riderMarker]);
    map.fitBounds(group.getBounds(), { padding: [50, 50] });
  }

  // --- Allow clicking map to move/add marker (disabled on order map) ---
  if (!IS_ORDER_MAP) {
    map.on("click", function (e) {
      const { lat, lng } = e.latlng;
      updateCustomerMarker(lat, lng);
    });
  }

  // --- Add My Location button ---
  if (addBtn && !IS_ORDER_MAP) {
    addBtn.addEventListener("click", function () {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            const lat = pos.coords.latitude;
            const lng = pos.coords.longitude;
            updateCustomerMarker(lat, lng);
          },
          () => {
            alert("Unable to access your location. Please allow location services.");
          }
        );
      } else {
        alert("Geolocation not supported by your browser.");
      }
    });
  }

  // --- Remove Marker button ---
  if (removeBtn && !IS_ORDER_MAP) {
    removeBtn.addEventListener("click", function () {
      if (customerMarker) {
        map.removeLayer(customerMarker);
        customerMarker = null;
        setLocation("", "");
        if (submitBtn) submitBtn.disabled = true;
        if (routeLine) {
          map.removeLayer(routeLine);
          routeLine = null;
        }
      }
    });
  }

  // --- Rider auto-tracking ---
  if (typeof USER_ROLE !== "undefined" && USER_ROLE === "rider") {
    riderMarker = L.marker(map.getCenter(), { icon: riderIcon, title: "Rider" }).addTo(map);

    if (navigator.geolocation) {
      navigator.geolocation.watchPosition(function (pos) {
        const { latitude: lat, longitude: lng } = pos.coords;
        updateRiderMarker(lat, lng);
        safeSend({ lat, lng, role: "rider" });
      });
    }
  }

  // --- ETA toggle ---
  const toggleBtn = document.getElementById("toggle-info");
  const etaContent = document.getElementById("eta-content");
  if (toggleBtn && etaContent) {
    toggleBtn.addEventListener("click", function () {
      etaContent.style.display = etaContent.style.display === "block" ? "none" : "block";
      toggleBtn.innerText = etaContent.style.display === "block" ? "Hide Info" : "Show Info";
    });
  }

  // --- Simulate Rider button ---
  const simulateBtn = document.getElementById("simulate-rider");
  if (simulateBtn) {
    simulateBtn.addEventListener("click", function () {
      console.log("[SIM] Starting rider simulation...");
      drawRoute(true);
    });
  }
});
