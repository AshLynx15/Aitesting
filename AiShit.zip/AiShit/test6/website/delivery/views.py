from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse, HttpResponseForbidden
from .models import Rider, Delivery, DeliveryLocation
from webpage.models import Order
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
import json

@login_required
def map_view(request):
    role = request.user.userprofile.role
    return render(request, 'delivery_app/map.html', {'role': role})

@login_required
def rider_location_view(request):
    rider = Rider.objects.get(user=request.user)
    return render(request, 'delivery_app/rider_location.html', {'rider': rider})

@login_required
def calculate_route_view(request):
    if request.method == 'POST':
        customer_location = request.POST.get('customer_location')
        rider = Rider.objects.get(user=request.user)
        rider_location = rider.location
        
        # Here you would implement the logic to calculate the route and ETA
        # For demonstration, we will return a mock response
        estimated_time = 15  # Mock estimated time in minutes
        route = {
            'rider_location': rider_location,
            'customer_location': customer_location,
            'estimated_time': estimated_time
        }
        return JsonResponse(route)
    
    return JsonResponse({'error': 'Invalid request'}, status=400)

@csrf_exempt
@login_required
def update_location(request, order_id):
    if request.method == 'POST':
        data = json.loads(request.body)
        lat = data.get('latitude')
        lng = data.get('longitude')
        is_rider = data.get('is_rider', False)

        order = get_object_or_404(Order, id=order_id)

        DeliveryLocation.objects.update_or_create(
            user=request.user,
            order=order,
            is_rider=is_rider,
            defaults={'latitude': lat, 'longitude': lng}
        )
        return JsonResponse({'status': 'ok'})
    return JsonResponse({'error': 'Invalid request'}, status=400)

def get_locations(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    locations = DeliveryLocation.objects.filter(order=order)
    data = [
        {'user': loc.user.username, 'lat': loc.latitude, 'lng': loc.longitude, 'is_rider': loc.is_rider}
        for loc in locations
    ]
    return JsonResponse({'locations': data})


@login_required
def customer_orders(request):
    orders = Order.objects.filter(user=request.user)
    return render(request, 'delivery_app/customer_orders.html', {'orders': orders})


@login_required
def rider_orders(request):
    orders = (
        Order.objects
        .filter(rider=request.user)
        .exclude(status__in=["delivered", "cancelled"])
        .order_by("-created_at")
    )
    return render(request, "delivery_app/rider_orders.html", {"orders": orders})


@login_required
def order_map(request, order_id):
    order = get_object_or_404(Order, pk=order_id)

    # check role
    is_customer = hasattr(order, 'customer') and order.customer_id == request.user.id
    is_rider = hasattr(order, 'rider') and order.rider_id == request.user.id
    if not (is_customer or is_rider):
        return HttpResponseForbidden("You are not allowed to view this order map.")

    role = 'rider' if is_rider else 'customer'

    # fetch delivery locations
    customer_loc = DeliveryLocation.objects.filter(order=order, is_rider=False).first()
    rider_loc = DeliveryLocation.objects.filter(order=order, is_rider=True).first()

    return render(request, 'delivery_app/order_map.html', {
        'order': order,
        'role': role,
        'customer_lat': customer_loc.latitude if customer_loc else None,
        'customer_lng': customer_loc.longitude if customer_loc else None,
        'rider_lat': rider_loc.latitude if rider_loc else None,
        'rider_lng': rider_loc.longitude if rider_loc else None,
    })


@login_required
def available_orders(request):
    orders = Order.objects.filter(rider__isnull=True, status="pending")
    return render(request, "delivery_app/available_orders.html", {"orders": orders})


@login_required
def claim_order(request, order_id):
    order = get_object_or_404(Order, id=order_id, status='pending')

    if request.method == 'POST':
        # Ensure Rider exists for this user
        rider, _ = Rider.objects.get_or_create(
            user=request.user,
            defaults={
                "name": request.user.get_full_name() or request.user.username,
                "location": ""
            }
        )

        # Link rider (user-level for Order)
        order.rider = request.user
        order.status = 'accepted'
        order.save()

        # Create or get Delivery
        delivery, created = Delivery.objects.get_or_create(
            order=order,
            defaults={'rider': rider, 'status': 'assigned'}
        )
        if not created:
            delivery.rider = rider
            delivery.status = "assigned"
            delivery.save()

        # Save rider location
        rider_lat = request.POST.get('rider_latitude')
        rider_lng = request.POST.get('rider_longitude')
        if not rider_lat or not rider_lng:
            customer_loc = order.locations.filter(is_rider=False).first()
            if customer_loc:
                rider_lat, rider_lng = customer_loc.latitude, customer_loc.longitude
            else:
                rider_lat, rider_lng = 14.5995, 120.9842  # Manila fallback

        DeliveryLocation.objects.update_or_create(
            user=request.user,
            order=order,
            is_rider=True,
            defaults={'latitude': rider_lat, 'longitude': rider_lng}
        )

        messages.success(request, f"Order #{order.id} accepted.")
        return redirect('delivery:available_orders')

    return redirect('delivery:available_orders')

@login_required
def rider_success(request, pk):
    order = get_object_or_404(Order, pk=pk)

    # ✅ Ensure a Delivery exists (in case it was never created for some reason)
    delivery, _ = Delivery.objects.get_or_create(order=order)

    if request.method == "POST":
        # Mark both order + delivery as delivered
        order.status = "delivered"
        order.save()

        delivery.status = "delivered"
        delivery.save()

        messages.success(request, f"Order #{order.id} has been marked as delivered.")
        return redirect("homepage")


    return render(request, "delivery_app/rider_success.html", {
        "order": order,
        "delivery": delivery,
    })


