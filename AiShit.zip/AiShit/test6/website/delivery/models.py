from django.db import models
from django.contrib.auth.models import User
from webpage.models import Order

class Rider(models.Model):
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=255)
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.name

class Delivery(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('assigned', 'Assigned'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
    ]

    order = models.OneToOneField("webpage.Order", on_delete=models.CASCADE, related_name="delivery")
    rider = models.ForeignKey("delivery.Rider", on_delete=models.SET_NULL, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')

    def __str__(self):
        return f"Delivery for Order {self.order.id} ({self.status})"


class DeliveryLocation(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="locations")
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    latitude = models.FloatField()
    longitude = models.FloatField()
    is_rider = models.BooleanField(default=False)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        who = "Rider" if self.is_rider else "Customer"
        return f"{who} location for Order {self.order.id}"


