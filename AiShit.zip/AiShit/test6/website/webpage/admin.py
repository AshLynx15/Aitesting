from django.contrib import admin
from .models import UserProfile, Order, Product, OrderItem, Feedback

# === USER PROFILE ADMIN ===
@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    # Show all fields in list view
    list_display = [field.name for field in UserProfile._meta.fields]

    # Helpful filters and search
    list_filter = ('role',)
    search_fields = (
        'user__username',
        'user__email',
        'address',
        'phone_number',
    )


# === ORDER ADMIN ===
@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    # Show all fields in list view
    list_display = [field.name for field in Order._meta.fields]

    # Filters for easier management
    list_filter = ('status', 'created_at')

    # Search across useful fields
    search_fields = (
        'id',
        'user__username',
        'user__email',
        'status',
        'address',
        'product_name',
    )


# === PRODUCT ADMIN ===
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    # Show key fields in list view
    list_display = ["name", "type", "has_sizes", "price_16oz", "price_32oz", "price", "stocks_quantity", "is_active", "date"]

    # Filters
    list_filter = ("type", "has_sizes", "date")

    # Search
    search_fields = ("name", "unique_id")

    # Keep unique_id uneditable
    readonly_fields = ("unique_id",)

    # Fieldsets for better editing experience
    fieldsets = (
        (None, {
            "fields": ("name", "type", "image", "has_sizes", "price_16oz", "price_32oz", "price", "stocks_quantity", "is_active", "date")
        }),
    )

@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ("id", "order", "product", "quantity", "price_at_order", "get_total_display")
    list_filter = ("order__status", "product__type")
    search_fields = ("order__order_id", "product__name")

    def get_total_display(self, obj):
        return obj.get_total()
    get_total_display.short_description = "Line Total"

@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ("id", "order", "user", "rating", "feedback", "created_at")
    list_filter = ("rating", "created_at")
    search_fields = ("feedback", "user__username", "order__id")
    ordering = ("-created_at",)