# webpage/utils.py
import re
import difflib
import spacy

# Load spaCy NLP model once
try:
    nlp = spacy.load("en_core_web_sm")
except Exception:
    nlp = spacy.blank("en")

def normalize_text(text):
    """Normalize user input for better matching."""
    text = (text or "").strip().lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()

    if not text:
        return text

    doc = nlp(text)
    tokens = [
        (token.lemma_.lower() if token.lemma_ else token.text.lower())
        for token in doc
        if not token.is_stop and not token.is_space
    ]
    return " ".join(tokens) if tokens else text


def get_customization_options(product_type):
    """Return available customization options depending on product type."""
    options = {}
    if product_type == 'milkteas':
        options['sugar'] = ['Original', '75%', '50%', '25%', '0%']
        options['ice'] = ['Original', '75%', '50%', '25%', '0%']
        options['add_on'] = ['tapioca', 'crystal', 'none']
    elif product_type == 'premium_flavors':
        options['sugar'] = ['Original', '75%', '50%', '25%', '0%']
        options['ice'] = ['Original', '75%', '50%', '25%', '0%']
        options['tapioca'] = [True, False]
    elif product_type == 'frappes':
        options['sugar'] = ['Original', '75%', '50%', '25%', '0%']
        options['ice'] = ['Original', '75%', '50%', '25%', '0%']
        options['add_on'] = ['tapioca', 'crystal', 'none']
        options['whipped_cream'] = [True, False]
    elif product_type == 'coffees':
        options['sugar'] = ['Original', '75%', '50%', '25%', '0%']
        options['milk'] = [True, False]
        options['whipped_cream'] = [True, False]
        options['iced'] = [True, False]
    elif product_type == 'sandwiches':
        options['no_onions'] = [True, False]
        options['no_salt'] = [True, False]

    return options
