
from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm
from .models import Product, UserProfile
import uuid
from django.db import models


class ChangeProfileForm(forms.ModelForm):

    phone_number = forms.CharField(
        max_length=11,
        min_length=10,
        widget=forms.TextInput(attrs={'placeholder': '9123456789', 'style': 'width:calc(100% - 120px);display:inline-block;'}),
        required=True
    )

    class Meta:
        model = UserProfile
        fields = ['address', 'phone_number', 'date_of_birth', 'profile_image']
        widgets = {
            'date_of_birth': forms.DateInput(attrs={'type': 'date'}),
        }

    def clean_phone_number(self):
        phone = self.cleaned_data.get('phone_number', '')
        # Only digits, length must be exactly 11
        import re
        if not re.match(r'^\d{11}$', phone):
            raise forms.ValidationError('Enter an 11-digit mobile number (e.g. 09123456789).')
        return phone

class LoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Username'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))



class RegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))
    confirm_password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Confirm Password'}))
    first_name = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'placeholder': 'First Name'}))
    last_name = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'placeholder': 'Last Name'}))
    address = forms.CharField(max_length=255, widget=forms.TextInput(attrs={'placeholder': 'Address'}))
    phone_number = forms.CharField(
        max_length=11,
        min_length=10,
        widget=forms.TextInput(attrs={'placeholder': 'Number'}),
        required=True
    )
    date_of_birth = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'placeholder': 'Date of Birth'}))

    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'first_name', 'last_name']

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")
        if password and confirm_password and password != confirm_password:
            self.add_error('confirm_password', "Passwords do not match")
        return cleaned_data
    
    def clean_phone_number(self):
        phone = self.cleaned_data.get('phone_number', '')
        import re
        if not re.match(r'^\d{11}$', phone):
            raise forms.ValidationError('Enter an 11-digit mobile number (e.g. 09123456789).')
        return phone

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        if commit:
            user.save()
            # ✅ Automatically create UserProfile with default role = 'customer'
            profile, created = UserProfile.objects.get_or_create(user=user)
            profile.address = self.cleaned_data['address']
            profile.phone_number = self.cleaned_data['phone_number']
            profile.date_of_birth = self.cleaned_data['date_of_birth']
            profile.role = 'customer'  # ✅ default
            profile.save()
        return user



class ProductForm(forms.ModelForm):
    has_sizes = forms.BooleanField(required=False, widget=forms.CheckboxInput())
    price_16oz = forms.DecimalField(required=False, max_digits=10, decimal_places=2)
    price_32oz = forms.DecimalField(required=False, max_digits=10, decimal_places=2)
    price = forms.DecimalField(required=False, max_digits=10, decimal_places=2)

    class Meta:
        model = Product
        fields = ['name', 'type', 'image', 'has_sizes', 'price_16oz', 'price_32oz', 'price']

    def clean(self):
        cleaned_data = super().clean()
        has_sizes = cleaned_data.get('has_sizes')
        price_16oz = cleaned_data.get('price_16oz')
        price_32oz = cleaned_data.get('price_32oz')
        price = cleaned_data.get('price')

        if has_sizes:
            # Set fallback price before raising errors
            if not price:
                cleaned_data['price'] = price_16oz or price_32oz
                price = cleaned_data['price']
            if not price_16oz:
                self.add_error('price_16oz', 'Price for 16oz is required when sizes are enabled.')
            if not price_32oz:
                self.add_error('price_32oz', 'Price for 32oz is required when sizes are enabled.')
        else:
            if not price:
                self.add_error('price', 'Single price is required when sizes are not enabled.')
            # Clear size prices
            cleaned_data['price_16oz'] = None
            cleaned_data['price_32oz'] = None
        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        # Ensure unused fields are set to None
        if self.cleaned_data.get('has_sizes'):
            # If fallback price is not set, use 16oz price
            if not instance.price:
                instance.price = self.cleaned_data.get('price_16oz') or self.cleaned_data.get('price_32oz')
        else:
            instance.price_16oz = None
            instance.price_32oz = None
        if commit:
            instance.save()
        return instance
