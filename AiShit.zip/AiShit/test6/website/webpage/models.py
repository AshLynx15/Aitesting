import uuid
from django.db import models
from django.conf import settings
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models import JSONField


class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    address = models.CharField(max_length=255, blank=True)
    phone_number = models.CharField(max_length=20, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    profile_image = models.ImageField(upload_to='profile_images/', blank=True, null=True)

    ROLE_CHOICES = (
        ('customer', 'Customer'),
        ('rider', 'Rider'),
    )
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='customer')

    def __str__(self):
        return f"{self.user.username}'s profile"


class Product(models.Model):
    PRODUCT_TYPES = [
        ('milkteas', 'Milk Teas'),
        ('premium_flavors', 'Premium Flavors'),
        ('frappes', 'Frappes'),
        ('coffees', 'Coffees'),
        ('sandwiches', 'Sandwiches'),
    ]
    unique_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    name = models.CharField(max_length=255)
    date = models.DateField(default=timezone.now)
    type = models.CharField(max_length=50, choices=PRODUCT_TYPES)
    image = models.ImageField(upload_to='product_images/', blank=True, null=True)
    stocks_quantity = models.PositiveIntegerField(default=0, help_text="Current stock quantity for this product.")
    is_active = models.BooleanField(default=True, help_text="Set to False to disable product (hide from customers)")

    SIZES = [
        ("16oz", "16 oz"),
        ("32oz", "32 oz"),
    ]
    has_sizes = models.BooleanField(default=False)
    price_16oz = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    price_32oz = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)  # fallback/default

    def get_price(self, size=None):
        if self.has_sizes and size:
            if size == "16oz" and self.price_16oz:
                return self.price_16oz
            elif size == "32oz" and self.price_32oz:
                return self.price_32oz
        return self.price

    def __str__(self):
        return f"{self.name} ({self.unique_id})"

    class Meta:
        ordering = ['-date']
        verbose_name_plural = "Products"


class Order(models.Model):
    order_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="orders")
    rider = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="deliveries")

    address = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('preparing', 'Preparing'),
        ('waiting_rider', 'Waiting for Rider'),
        ('in_transit', 'In Transit'),
        ('delivered', 'Delivered'),
        ('cancelled', 'Cancelled'),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')

    @property
    def total_price(self):
        """Sum of all item totals in the order."""
        return sum(item.get_total() for item in self.items.all())

    def __str__(self):
        return f"Order {self.order_id} ({self.get_status_display()})"

    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = "Orders"


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    price_at_order = models.DecimalField(max_digits=10, decimal_places=2)
    customizations = JSONField(default=dict, blank=True)

    def get_total(self):
        return self.price_at_order * self.quantity

    def __str__(self):
        return f"{self.quantity} x {self.product.name} (Order {self.order.order_id})"


class Feedback(models.Model):
    order = models.OneToOneField(Order, on_delete=models.CASCADE, related_name="feedback")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="feedbacks")
    rating = models.PositiveIntegerField(choices=[(i, str(i)) for i in range(1, 6)])
    feedback = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback for Order {self.order.id} by {self.user.username}"
