from django.urls import path
from django.contrib.auth.views import LogoutView
from . import views
from .views import disable_product_view, enable_product_view, edit_stock_view

urlpatterns = [
    path('change-profile/', views.change_profile_view, name='change_profile'),
    path('', views.homepage, name='homepage'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', LogoutView.as_view(template_name='log-reg/logout.html'), name='logout'),
    path('add-product/', views.add_product_view, name='add_product'),
    path('delete-product/<int:pk>/', views.delete_product_view, name='delete_product'),
    path('edit-product/<int:pk>/', views.edit_product_view, name='edit_product'),
    path('order/customize/<int:pk>/', views.customize_order_view, name='customize_order'),
    path('cart/', views.cart_view, name='cart'),
    path('cart/submit/', views.submit_cart_view, name='submit_cart'),
    path('cart/cancel/', views.cancel_cart_view, name='cancel_cart'),
    path('orders/', views.user_order_list_view, name='user_order_list'),
    path('orders/history/', views.user_order_history_view, name='user_order_history'),
    path('orders/receipts/', views.user_order_receipt_list_view, name='user_order_receipt_list'),
    path('orders/receipt/<int:order_id>/', views.order_receipt_view, name='order_receipt'),
    path('owner/orders/', views.admin_order_list_view, name='admin_order_list'),
    path('owner/orders/<int:order_id>/update/', views.update_order_status_view, name='update_order_status'),
    path('owner/orders/<int:order_id>/delete/', views.delete_order_view, name='delete_order'),
    path('orders/<int:pk>/', views.order_detail, name='order_detail'),
    path("orders/<int:pk>/customer-feedback/", views.customer_feedback, name="customer_feedback"),
    path("cart/remove/<int:item_id>/", views.remove_cart_item, name="remove_cart_item"),
    path("cart/increase/<int:product_id>/", views.increase_cart_quantity, name="increase_cart_quantity"),
    path("cart/decrease/<int:product_id>/", views.decrease_cart_quantity, name="decrease_cart_quantity"),
    path('chatbot-response/', views.chatbot_response_view, name='chatbot_response'),
    path('disable-product/<int:product_id>/', disable_product_view, name='disable_product'),
    path('stocks/', views.admin_stock_list, name='admin_stock_list'),
    path('enable-product/<int:product_id>/', enable_product_view, name='enable_product'),
    path('edit-stock/<int:product_id>/', edit_stock_view, name='edit_stock'),
    path('sales-overall/', views.sales_overall_view, name='sales_overall'),
    path('customer-feedback/', views.list_customer_feedback_view, name='list_customer_feedback'),
    path('order-history/', views.list_order_history_view, name='list_order_history'),
]