document.addEventListener('DOMContentLoaded', function() {
    const modalBox = document.getElementById('modalBox');
    const modalContent = document.getElementById('modalContent');
    const loginFormBox = document.getElementById('loginForm');
    const registerFormBox = document.getElementById('registerForm');
    const closeModal = document.getElementById('closeModal');

    // Navbar buttons
    document.querySelectorAll('nav #loginBtn').forEach(btn => {
        btn.addEventListener('click', function() {
            modalBox.classList.add('active');
            modalContent.classList.remove('show-register');
            setTimeout(adjustModalHeight, 10);
        });
    });
    document.querySelectorAll('nav #registerBtn').forEach(btn => {
        btn.addEventListener('click', function() {
            modalBox.classList.add('active');
            modalContent.classList.add('show-register');
            setTimeout(adjustModalHeight, 10);
        });
    });

    // Modal switch buttons
    document.querySelectorAll('.switch-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            if (btn.dataset.switch === 'login') {
                modalContent.classList.remove('show-register');
            } else if (btn.dataset.switch === 'register') {
                modalContent.classList.add('show-register');
            }
            setTimeout(adjustModalHeight, 10);
        });
    });

    if (closeModal) {
        closeModal.addEventListener('click', function() {
            modalBox.classList.remove('active');
        });
    }
    if (modalBox) {
        modalBox.addEventListener('click', function(e) {
            if (e.target === modalBox) {
                modalBox.classList.remove('active');
            }
        });
    }

    function adjustModalHeight() {
        const modalContent = document.getElementById('modalContent');
        const loginFormBox = document.getElementById('loginForm');
        const registerFormBox = document.getElementById('registerForm');
        let activeForm = modalContent.classList.contains('show-register') ? registerFormBox : loginFormBox;
        // Temporarily set height to current for smooth transition
        modalContent.style.height = activeForm.offsetHeight + "px";
        // After transition, let it go back to auto
        setTimeout(() => {
            modalContent.style.height = "auto";
        }, 350);
    }
});