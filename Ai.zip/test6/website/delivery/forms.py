from django import forms
from delivery.models import Delivery

class DeliveryForm(forms.ModelForm):
    class Meta:
        model = Delivery
        fields = ['customer_location']  # Add any other fields as necessary
        widgets = {
            'customer_location': forms.TextInput(attrs={'placeholder': 'Enter customer location'}),
        }