from .models import Product, OrderItem
from django.db.models import Count

def simple_response(user, message):
    message = message.lower().strip()

    # --- 1. Product lookup ---
    product = Product.objects.filter(name__icontains=message).first()
    if product:
        response = f"{product.name} is one of our {product.get_type_display()}."
        if product.has_sizes:
            sizes = []
            if product.price_16oz:
                sizes.append(f"16oz ₱{product.price_16oz}")
            if product.price_32oz:
                sizes.append(f"32oz ₱{product.price_32oz}")
            size_text = " and ".join(sizes)
            response += f" Available in {size_text}."
        else:
            response += f" It costs ₱{product.price}."
        response += " You can customize sweetness and ice level, too!"
        return response

    # --- 2. Personalized recommendation ---
    if user and user.is_authenticated:
        top_items = (
            OrderItem.objects.filter(order__customer=user)
            .values("product__type")
            .annotate(total=Count("id"))
            .order_by("-total")
        )
        if top_items.exists():
            fav_type = top_items[0]["product__type"]
            similar_products = Product.objects.filter(type=fav_type)[:3]
            names = ", ".join(p.name for p in similar_products)
            return f"Since you enjoy our {Product.PRODUCT_TYPES_DICT.get(fav_type, fav_type)}, you might also like {names}!"

    # --- 3. Friendly responses ---
    if any(word in message for word in ["hi", "hello", "hey"]):
        return "Hello! How can I help you today? You can ask about any drink or snack we offer."

    if "recommend" in message:
        return "Sure! Our bestsellers include Okinawa Milk Tea, Classic Milk Tea, and Wintermelon Milk Tea."

    if "thank" in message:
        return "You're very welcome! 😊"

    # --- 4. Fallback ---
    return "I'm here to help you explore our menu! Try asking about a drink name or say 'recommend something.'"
