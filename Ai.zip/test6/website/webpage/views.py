from .forms import ChangeProfileForm
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.decorators import user_passes_test, login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.views.decorators.http import require_POST
from .forms import LoginForm, RegisterForm, ProductForm
from .models import Product, Order, UserProfile, OrderItem, Feedback
from delivery.models import DeliveryLocation, Delivery
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User
from django.contrib import messages
from django.db import transaction
from django.http import JsonResponse
from .chatbot_logic import simple_response
from webpage.utils import normalize_text, get_customization_options

ACTIVE_STATUSES = ["pending", "accepted", "preparing", "waiting_rider", "in_transit"]
FINISHED_STATUSES = ["delivered", "cancelled"]

def homepage(request):
    search_query = request.GET.get('search', '')

    products = Product.objects.all()
    if search_query:
        products = products.filter(name__icontains=search_query)

    # Sort products: in-stock first, out-of-stock last
    products = sorted(products, key=lambda p: (p.stocks_quantity == 0, p.name.lower()))

    # Pagination: 8 products per page
    from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
    paginator = Paginator(products, 8)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    show_login_modal = False
    show_register_modal = False

    # Default forms for GET requests
    login_form = LoginForm(request)
    register_form = RegisterForm()

    if request.method == 'POST':
        # ✅ LOGIN PROCESS
        if 'login' in request.POST:
            login_form = LoginForm(request, data=request.POST)  # validate login form
            register_form = RegisterForm()  # empty
            show_login_modal = True
            if login_form.is_valid():
                user = login_form.get_user()
                auth_login(request, user)
                return redirect('/')
            else:
                messages.error(request, "Invalid username or password.")

        # ✅ REGISTER PROCESS
        elif 'register' in request.POST:
            register_form = RegisterForm(request.POST)  # validate register form
            login_form = LoginForm(request)  # empty
            show_register_modal = True
            if register_form.is_valid():
                user = register_form.save()
                auth_login(request, user)
                messages.success(request, f"Welcome, {user.username}! Your account has been created.")
                return redirect('/')
            else:
                messages.error(request, "Please fix the errors below and try again.")

    return render(request, 'dashboard/homepage.html', {
        'login_form': login_form,
        'register_form': register_form,
        'products': page_obj.object_list,
        'page_obj': page_obj,
        'search_query': search_query,
        'show_login_modal': show_login_modal,
        'show_register_modal': show_register_modal,
    })

def login_view(request):
    login_form = LoginForm(request, data=request.POST or None)
    register_form = RegisterForm()
    show_login_modal = False

    if request.method == 'POST':
        show_login_modal = True
        if login_form.is_valid():
            user = login_form.get_user()
            auth_login(request, user)
            return redirect('/')
        else:
            return redirect('homepage')

    return render(request, 'dashboard/homepage.html', {
        'login_form': login_form,
        'register_form': register_form,
        'show_login_modal': show_login_modal,
    })


def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            messages.success(request, f"Welcome, {user.username}! Your account has been created.")
            return redirect('/')
        else:
            messages.error(request, "Please correct the errors below and try again.")
    else:
        form = RegisterForm()

    return render(request, 'log-reg/register.html', {'form': form})

def is_admin(user):
    return user.is_superuser

@login_required
@user_passes_test(is_admin)
def add_product_view(request):
    form = ProductForm(request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        form.save()
        return redirect('add_product')
    query = request.GET.get('search', '')
    products = Product.objects.all().order_by('-date')
    if query:
        products = products.filter(name__icontains=query)

    from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
    paginator = Paginator(products, 8)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    return render(request, 'dashboard/admin-nav/add_product.html', {
        'form': form,
        'products': products,
        'page_obj': page_obj,
        'search_query': query,
    })

@login_required
@user_passes_test(is_admin)
def delete_product_view(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        product.delete()
        messages.success(request, f"Product '{product.name}' deleted successfully.")
        return redirect('add_product')
    return redirect('add_product')

@login_required
@user_passes_test(is_admin)
def edit_product_view(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            messages.success(request, f"Product '{product.name}' updated successfully!")
            return redirect('add_product')
    else:
        form = ProductForm(instance=product)
    return render(request, 'dashboard/admin-nav/edit_product.html', {'form': form, 'product': product})


@login_required
def customize_order_view(request, pk):
    product = get_object_or_404(Product, pk=pk)
    ingredient_options = get_customization_options(product.type)  # ✅ cleaner

    if request.method == 'POST':
        cart = request.session.get('cart', [])
        customization = {}

        selected_size = None
        if product.has_sizes:
            selected_size = request.POST.get('size')
            customization['size'] = selected_size

        # Remove water level, add tapioca/crystal/none for milktea and frappe
        if product.type == 'milkteas':
            customization['sugar'] = request.POST.get('sugar')
            customization['ice'] = request.POST.get('ice')
            customization['add_on'] = request.POST.get('add_on')  # 'tapioca', 'crystal', 'none'
        elif product.type == 'premium_flavors':
            customization['sugar'] = request.POST.get('sugar')
            customization['ice'] = request.POST.get('ice')
            customization['tapioca'] = bool(request.POST.get('tapioca'))
        elif product.type == 'frappes':
            customization['sugar'] = request.POST.get('sugar')
            customization['ice'] = request.POST.get('ice')
            customization['add_on'] = request.POST.get('add_on')  # 'tapioca', 'crystal', 'none'
            customization['whipped_cream'] = bool(request.POST.get('whipped_cream'))
        elif product.type == 'coffees':
            customization['sugar'] = request.POST.get('sugar')
            customization['milk'] = bool(request.POST.get('milk'))
            customization['whipped_cream'] = bool(request.POST.get('whipped_cream'))
            customization['iced'] = bool(request.POST.get('iced'))
        elif product.type == 'sandwiches':
            customization['no_onions'] = bool(request.POST.get('no_onions'))
            customization['no_salt'] = bool(request.POST.get('no_salt'))

        if product.has_sizes and selected_size:
            if selected_size == '16oz' and product.price_16oz:
                price = float(product.price_16oz)
            elif selected_size == '32oz' and product.price_32oz:
                price = float(product.price_32oz)
            else:
                price = float(product.price)
        else:
            price = float(product.price)

        # Check if already in cart, update quantity
        found = False
        for cart_item in cart:
            if cart_item['product_id'] == product.id:
                # Increase quantity but do not exceed stocks_quantity
                new_qty = cart_item['quantity'] + 1
                cart_item['quantity'] = min(new_qty, product.stocks_quantity)
                found = True
                break
        if not found:
            cart.append({
                'product_id': product.id,
                'name': product.name,
                'type': product.type,
                'price': price,
                'customizations': customization,
                'quantity': 1,
            })
        request.session['cart'] = cart
        return redirect('cart')

    customer_name = request.user.username if request.user.is_authenticated else "Guest"
    return render(request, 'orders/customize_order.html', {
        'product': product,
        'ingredient_options': ingredient_options,
        'customer_name': customer_name,
        # Add context for template to show add_on options for milktea/frappes
        'show_add_on_radial': product.type in ['milkteas', 'frappes'],
    })

@login_required
def cart_view(request):
    session_cart = request.session.get('cart', [])
    cart_items = []
    grand_total = 0

    for item in session_cart:
        product = Product.objects.filter(id=item['product_id']).first()
        if product:
            # Limit quantity to available stock
            quantity = min(item['quantity'], product.stocks_quantity)
            subtotal = float(product.price) * quantity
            grand_total += subtotal
            cart_items.append({
                'product': product,
                'product_id': item['product_id'],
                'quantity': quantity,
                'price': float(product.price),   # unit price
                'subtotal': subtotal,            # per line total
                'customizations': item.get('customizations', {})
            })

    return render(
        request,
        'orders/cart.html',
        {
            'cart': cart_items,
            'session_cart': session_cart,
            'grand_total': grand_total
        }
    )



@login_required
def submit_cart_view(request):
    if request.method != 'POST':
        return redirect('cart')

    cart = request.session.get('cart', [])
    address_option = request.POST.get('address_option')
    custom_address = request.POST.get('address', '').strip()

    if address_option == 'default':
        address = getattr(request.user.userprofile, 'address', '').strip()
    else:
        address = custom_address

    lat = request.POST.get('latitude')
    lng = request.POST.get('longitude')

    if not cart:
        messages.error(request, "Your cart is empty.")
        return redirect('cart')

    if not address:
        messages.error(request, "Please provide a delivery address.")
        return redirect('cart')

    if not lat or not lng:
        messages.error(request, "Please pin your delivery location on the map.")
        return redirect('cart')

    try:
        lat_f, lng_f = float(lat), float(lng)
        if not (-90 <= lat_f <= 90 and -180 <= lng_f <= 180):
            raise ValueError("Coordinates out of range")
    except (ValueError, TypeError):
        messages.error(request, "Invalid latitude or longitude.")
        return redirect('cart')

    # --- Atomic Save ---
    with transaction.atomic():
        order = Order.objects.create(
            customer=request.user,
            address=address,
            status='pending'
        )

        Delivery.objects.create(order=order, status="pending")

        DeliveryLocation.objects.create(
            user=request.user,
            order=order,
            is_rider=False,
            latitude=lat_f,
            longitude=lng_f
        )


        saved_items = 0
        for item in cart:
            try:
                product = Product.objects.get(id=item['product_id'])
            except Product.DoesNotExist:
                continue
            quantity = min(item.get('quantity', 1), product.stocks_quantity)
            if quantity <= 0:
                continue
            OrderItem.objects.create(
                order=order,
                product=product,
                quantity=quantity,
                price_at_order=product.price,
                customizations=item.get('customizations', {}),
            )
            # Decrease product stock
            product.stocks_quantity -= quantity
            product.save()
            saved_items += 1

        if saved_items == 0:
            transaction.set_rollback(True)
            messages.error(request, "Your cart contained invalid items or insufficient stock. Please try again.")
            return redirect('cart')


    request.session['cart'] = []
    messages.success(request, f"Order #{order.id} has been submitted successfully!")

    return redirect('homepage')




@login_required
def user_order_list_view(request):
    orders = (
        Order.objects.filter(customer=request.user)
        .exclude(status__in=["delivered", "cancelled"])
        .order_by("-created_at")
        .prefetch_related("items__product")
    )

    order_list = []
    for order in orders:
        items = []
        for item in order.items.all():
            items.append({
                "product_name": item.product.name,
                "customizations": getattr(item, "customizations", None),
                "quantity": item.quantity,
                "price": item.price_at_order,
            })
        order_list.append({
            "id": order.id,
            "created_at": order.created_at,
            "status": order.status,
            "get_status_display": order.get_status_display(),
            "rider": order.rider,
            "items": items,
            "total_price": sum(i["price"] * i["quantity"] for i in items),
        })

    return render(request, "orders/user_order_list.html", {"orders": order_list})


@staff_member_required
def admin_order_list_view(request):
    orders = Order.objects.all().order_by('-created_at')
    return render(request, 'orders/admin_order_list.html', {'orders': orders})

@staff_member_required
@require_POST
def update_order_status_view(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    new_status = request.POST.get('status')
    if new_status in dict(Order.STATUS_CHOICES):
        order.status = new_status
        order.save()
    return redirect('admin_order_list')

@staff_member_required
@require_POST
def delete_order_view(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    order.delete()
    return redirect('admin_order_list')

@login_required
def user_order_history_view(request):
    """Shows only finished/completed orders with totals prepared"""
    past_orders = (
        Order.objects.filter(customer=request.user, status__in=FINISHED_STATUSES)
        .order_by("-created_at")
    )

    for order in past_orders:
        order.item_list = [
            {
                "name": item.product.name,
                "qty": item.quantity,
                "customizations": item.customizations,
                "price_each": item.price_at_order,
                "subtotal": item.get_total(),
            }
            for item in order.items.all()
        ]

    return render(request, "orders/user_order_history.html", {"orders": past_orders})
@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.get_or_create(user=instance)

@login_required
def order_detail(request, pk):
    order = get_object_or_404(Order, pk=pk, customer=request.user)
    items = order.items.all()

    # Get saved customer location (if any)
    customer_location = order.locations.filter(is_rider=False).first()
    rider_location = order.locations.filter(is_rider=True).first()

    return render(request, 'orders/order_detail.html', {
        'order': order,
        'items': items,
        'customer_lat': customer_location.latitude if customer_location else None,
        'customer_lng': customer_location.longitude if customer_location else None,
        'rider_lat': rider_location.latitude if rider_location else None,
        'rider_lng': rider_location.longitude if rider_location else None,
    })



@login_required
def cancel_cart_view(request):
    if request.method == "POST":
        # ✅ Clear the session cart instead of querying a model
        request.session['cart'] = []
        messages.info(request, "Your cart has been canceled.")
        return redirect('cart')

@login_required
def customer_feedback(request, pk):
    order = get_object_or_404(Order, pk=pk, customer=request.user)

    if request.method == "POST":
        rating = request.POST.get("rating")
        feedback_text = request.POST.get("feedback")

        feedback, created = Feedback.objects.update_or_create(
            order=order,
            user=request.user,
            defaults={"rating": rating, "feedback": feedback_text}
        )

        if created:
            messages.success(request, "Thanks for your feedback!")
        else:
            messages.success(request, "Your feedback has been updated!")

        return redirect("homepage")

    return render(request, "orders/customer_feedback.html", {"order": order})

@property
def total_price(self):
    return sum(item.get_total() for item in self.items.all())


@login_required
def remove_cart_item(request, item_id):
    cart = request.session.get("cart", [])
    
    updated_cart = [item for item in cart if str(item["product_id"]) != str(item_id)]
    
    request.session["cart"] = updated_cart
    request.session.modified = True

    messages.success(request, "Item removed from your cart.")
    return redirect("cart")

@login_required
def increase_cart_quantity(request, product_id):
    cart = request.session.get("cart", [])
    for item in cart:
        if item["product_id"] == product_id:
            item["quantity"] += 1
            break
    request.session["cart"] = cart
    return redirect("cart")


@login_required
def decrease_cart_quantity(request, product_id):
    cart = request.session.get("cart", [])
    for item in cart:
        if item["product_id"] == product_id:
            if item["quantity"] > 1:
                item["quantity"] -= 1
            else:
                # if it reaches 0, remove the item
                cart = [i for i in cart if i["product_id"] != product_id]
            break
    request.session["cart"] = cart
    return redirect("cart")


@login_required
def chatbot_response_view(request):
    """
    Handles AJAX chatbot requests — returns smart text replies.
    """
    if request.method == "POST":
        user_message = request.POST.get("message", "")
        reply = simple_response(request.user, user_message)
        return JsonResponse({"reply": reply})
    return JsonResponse({"error": "Invalid request"}, status=400)

@login_required
@user_passes_test(is_admin)
@require_POST
def disable_product_view(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    product.stocks_quantity = 0
    product.is_active = False
    product.save()
    messages.success(request, f"Product '{product.name}' has been disabled and stock set to 0.")
    return redirect(request.META.get('HTTP_REFERER', 'homepage'))

@login_required
@user_passes_test(is_admin)
def admin_stock_list(request):
    products = Product.objects.all().order_by('stocks_quantity', 'name')
    return render(request, 'dashboard/admin-nav/stocks_quantity.html', {'products': products})

@login_required
@user_passes_test(is_admin)
@require_POST
def enable_product_view(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    product.is_active = True
    product.stocks_quantity += 1
    product.save()
    messages.success(request, f"Product '{product.name}' has been enabled and stock increased by 1.")
    return redirect(request.META.get('HTTP_REFERER', 'admin_stock_list'))

@login_required
@user_passes_test(is_admin)
def edit_stock_view(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        try:
            new_stock = int(request.POST.get('stocks_quantity', product.stocks_quantity))
            if new_stock < 0:
                raise ValueError
            product.stocks_quantity = new_stock
            product.save()
            messages.success(request, f"Stock for '{product.name}' updated to {new_stock}.")
            # ✅ Redirect to stock list after successful edit
            return redirect('admin_stock_list')
        except (ValueError, TypeError):
            messages.error(request, "Invalid stock value.")
            return redirect('admin_stock_list')  # Still redirect even on error
    return render(request, 'dashboard/admin-nav/edit_stock.html', {'product': product})

@login_required
@user_passes_test(is_admin)
def sales_overall_view(request):
    from django.db.models import Sum
    import datetime
    filter_type = request.GET.get('filter', 'day')
    date_str = request.GET.get('date')
    now = datetime.datetime.now()
    chart_labels = []
    chart_data = []
    # Parse selected date
    if date_str:
        try:
            if filter_type == 'day' or filter_type == 'week':
                selected = datetime.datetime.strptime(date_str, '%Y-%m-%d')
            elif filter_type == 'month':
                selected = datetime.datetime.strptime(date_str, '%Y-%m')
            elif filter_type == 'year':
                selected = datetime.datetime.strptime(date_str, '%Y')
            else:
                selected = now
        except Exception:
            selected = now
    else:
        selected = now

    if filter_type == 'day':
        start = selected.replace(hour=0, minute=0, second=0, microsecond=0)
        end = selected.replace(hour=23, minute=59, second=59, microsecond=999999)
        orders = Order.objects.filter(status="delivered", created_at__range=(start, end))
        for hour in range(24):
            hour_start = start + datetime.timedelta(hours=hour)
            hour_end = hour_start + datetime.timedelta(hours=1)
            total = orders.filter(created_at__gte=hour_start, created_at__lt=hour_end).aggregate(total=Sum('items__price_at_order'))['total'] or 0
            chart_labels.append(f"{hour:02d}:00")
            chart_data.append(float(total))
    elif filter_type == 'week':
        # selected is the first day of the week
        start = selected - datetime.timedelta(days=selected.weekday())
        start = start.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + datetime.timedelta(days=6, hours=23, minutes=59, seconds=59, microseconds=999999)
        orders = Order.objects.filter(status="delivered", created_at__range=(start, end))
        for i in range(7):
            day_start = start + datetime.timedelta(days=i)
            day_end = day_start + datetime.timedelta(days=1)
            total = orders.filter(created_at__gte=day_start, created_at__lt=day_end).aggregate(total=Sum('items__price_at_order'))['total'] or 0
            chart_labels.append(day_start.strftime('%a'))
            chart_data.append(float(total))
    elif filter_type == 'month':
        start = selected.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        next_month = (start + datetime.timedelta(days=32)).replace(day=1)
        end = next_month - datetime.timedelta(seconds=1)
        orders = Order.objects.filter(status="delivered", created_at__range=(start, end))
        days_in_month = (next_month - start).days
        for i in range(days_in_month):
            day_start = start + datetime.timedelta(days=i)
            day_end = day_start + datetime.timedelta(days=1)
            total = orders.filter(created_at__gte=day_start, created_at__lt=day_end).aggregate(total=Sum('items__price_at_order'))['total'] or 0
            chart_labels.append(day_start.strftime('%d'))
            chart_data.append(float(total))
    elif filter_type == 'year':
        start = selected.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
        end = selected.replace(month=12, day=31, hour=23, minute=59, second=59, microsecond=999999)
        orders = Order.objects.filter(status="delivered", created_at__range=(start, end))
        for month in range(1, 13):
            month_start = start.replace(month=month, day=1)
            if month == 12:
                month_end = end
            else:
                month_end = start.replace(month=month+1, day=1)
            total = orders.filter(created_at__gte=month_start, created_at__lt=month_end).aggregate(total=Sum('items__price_at_order'))['total'] or 0
            chart_labels.append(month_start.strftime('%b'))
            chart_data.append(float(total))
    else:
        start = selected.replace(hour=0, minute=0, second=0, microsecond=0)
        end = selected.replace(hour=23, minute=59, second=59, microsecond=999999)
        orders = Order.objects.filter(status="delivered", created_at__range=(start, end))
        for hour in range(24):
            hour_start = start + datetime.timedelta(hours=hour)
            hour_end = hour_start + datetime.timedelta(hours=1)
            total = orders.filter(created_at__gte=hour_start, created_at__lt=hour_end).aggregate(total=Sum('items__price_at_order'))['total'] or 0
            chart_labels.append(f"{hour:02d}:00")
            chart_data.append(float(total))

    return render(request, "dashboard/admin-nav/sales_Overall.html", {
        "chart_labels": chart_labels,
        "chart_data": chart_data,
        "filter_type": filter_type,
        "now": now,
    })

@login_required
@user_passes_test(is_admin)
def list_customer_feedback_view(request):
    customer_feedback = Feedback.objects.all()
    return render(request, "dashboard/admin-nav/list_customer_feedback.html", {
        "customer_feedback": customer_feedback
    })

@login_required
@user_passes_test(is_admin)
def list_order_history_view(request):
    orders = Order.objects.all()
    return render(request, "dashboard/admin-nav/order_history_list.html", {
        "orders": orders
    })

@login_required
def change_profile_view(request):
    profile = request.user.userprofile
    user = request.user
    if request.method == 'POST':
        form = ChangeProfileForm(request.POST, request.FILES, instance=profile)
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        password_confirm = request.POST.get('password_confirm', '')
        errors = []
        if username and username != user.username:
            if User.objects.filter(username=username).exclude(pk=user.pk).exists():
                errors.append('Username is already taken.')
            else:
                user.username = username
        if password:
            if password != password_confirm:
                errors.append('Passwords do not match.')
            elif len(password) < 6:
                errors.append('Password must be at least 6 characters.')
            else:
                user.set_password(password)
        if form.is_valid() and not errors:
            form.save()
            user.save()
            messages.success(request, 'Profile updated successfully!')
            # If password changed, re-authenticate
            if password:
                from django.contrib.auth import update_session_auth_hash
                update_session_auth_hash(request, user)
            return redirect('change_profile')
        else:
            for error in errors:
                messages.error(request, error)
    else:
        form = ChangeProfileForm(instance=profile)
    return render(request, 'dashboard/change_profile.html', {'form': form})
from django.contrib.auth.decorators import login_required

@login_required
def user_order_receipt_list_view(request):
    orders = (
        Order.objects.filter(customer=request.user)
        .order_by('-created_at')
    )
    return render(request, 'orders/user_order_receipt_list.html', {'orders': orders})

@login_required
def order_receipt_view(request, order_id):
    order = get_object_or_404(Order, id=order_id, customer=request.user)
    return render(request, 'orders/order_receipt.html', {'order': order})