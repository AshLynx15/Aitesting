import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
import os

def train_chatbot_model(csv_path, model_path, vectorizer_path):
    # Load labeled chat logs or training data
    df = pd.read_csv(csv_path)
    X = df['message']
    y = df['intent']

    vectorizer = TfidfVectorizer(ngram_range=(1,2), max_features=1000)
    X_vec = vectorizer.fit_transform(X)

    clf = RandomForestClassifier(n_estimators=100, random_state=42)
    clf.fit(X_vec, y)

    joblib.dump(clf, model_path)
    joblib.dump(vectorizer, vectorizer_path)
    print(f"Model and vectorizer saved to {model_path}, {vectorizer_path}")

if __name__ == "__main__":
    # Example usage: python train_model.py data.csv model.pkl vectorizer.pkl
    import sys
    if len(sys.argv) != 4:
        print("Usage: python train_model.py <data.csv> <model.pkl> <vectorizer.pkl>")
        exit(1)
    train_chatbot_model(sys.argv[1], sys.argv[2], sys.argv[3])
