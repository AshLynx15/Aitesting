from django.urls import path
from . import views
from .api import ChatbotAPIView

urlpatterns = [
    path("", views.chatbot_page, name="chat_page"),
    path("response/", views.chatbot_response, name="chat_response"),
    path("api/", ChatbotAPIView.as_view(), name="chatbot_api"),
]
