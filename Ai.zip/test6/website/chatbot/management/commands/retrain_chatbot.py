from django.core.management.base import BaseCommand
from chatbot.models import ChatLog
import pandas as pd
import os
from chatbot.ml.train_model import train_chatbot_model

class Command(BaseCommand):
    help = 'Retrain chatbot Random Forest model from labeled chat logs'

    def handle(self, *args, **options):
        logs = ChatLog.objects.exclude(admin_label='').values('message', 'admin_label')
        if not logs:
            self.stdout.write(self.style.ERROR('No labeled chat logs found.'))
            return
        df = pd.DataFrame(list(logs))
        csv_path = os.path.join(os.path.dirname(__file__), '../../ml/chatlog_labeled.csv')
        model_path = os.path.join(os.path.dirname(__file__), '../../ml/model.pkl')
        vectorizer_path = os.path.join(os.path.dirname(__file__), '../../ml/vectorizer.pkl')
        df.rename(columns={'admin_label': 'intent'}, inplace=True)
        df.to_csv(csv_path, index=False)
        train_chatbot_model(csv_path, model_path, vectorizer_path)
        self.stdout.write(self.style.SUCCESS('Chatbot model retrained and saved.'))
from django.core.management.base import BaseCommand
from chatbot.models import ChatbotTrainingData
from sklearn.feature_extraction.text import TfidfVectorizer
from chatbot.ml.model import MODEL_PATH
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib, os


class Command(BaseCommand):
    help = 'Retrain the chatbot model using training data from the database'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS("🔄 Starting chatbot model retraining..."))

        # Fetch training data from the DB
        data = ChatbotTrainingData.objects.all()
        sentences, labels = [], []

        for s in data:
            if s.message and s.intent:
                sentences.append(s.message.strip())
                labels.append(s.intent.strip())

        if not sentences:
            self.stdout.write(self.style.ERROR("No valid training data found — aborting retrain."))
            return

        # TF-IDF vectorizer for NLP preprocessing
        vectorizer = TfidfVectorizer(stop_words='english')
        X = vectorizer.fit_transform(sentences)

        # Train the RandomForest model
        model = RandomForestClassifier(n_estimators=200, random_state=42)
        model.fit(X, labels)

        # Save both model and vectorizer in sync (tuple)
        os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
        joblib.dump((model, vectorizer), MODEL_PATH)

        self.stdout.write(self.style.SUCCESS(f"✅ Chatbot model retrained successfully and saved to {MODEL_PATH}"))
